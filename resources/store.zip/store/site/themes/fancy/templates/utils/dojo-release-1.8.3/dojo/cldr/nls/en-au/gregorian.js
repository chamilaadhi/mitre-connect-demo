/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-au/gregorian",{"dateFormatItem-yMd":"d/M/y","dateFormat-medium":"dd/MM/yyyy","dateFormatItem-MMMEd":"E, d MMM","dateFormatItem-MMdd":"dd/MM","dateFormatItem-MEd":"E, d/M","dateFormatItem-yMEd":"E, d/M/y","dateFormatItem-yMMMd":"d MMM y","timeFormat-full":"h:mm:ss a zzzz","dateFormatItem-yyyyMMMM":"MMMM y","dateFormatItem-MMMMd":"d MMMM","dateFormatItem-yyyyMM":"MM/yyyy","timeFormat-medium":"h:mm:ss a","dateFormat-long":"d MMMM y","dateFormat-short":"d/MM/yy","timeFormat-short":"h:mm a","timeFormat-long":"h:mm:ss a z","dateFormat-full":"EEEE, d MMMM y","dateFormatItem-MMMd":"d MMM"});
