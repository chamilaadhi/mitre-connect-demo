/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sl/currency",{"HKD_displayName":"hongkonški dolar","CHF_displayName":"švicarski frank","JPY_symbol":"¥","CAD_displayName":"kanadski dolar","CNY_displayName":"kitajski juan renminbi","USD_symbol":"$","AUD_displayName":"avstralski dolar","JPY_displayName":"japonski jen","USD_displayName":"ameriški dolar","GBP_displayName":"britanski funt","EUR_displayName":"evro"});
