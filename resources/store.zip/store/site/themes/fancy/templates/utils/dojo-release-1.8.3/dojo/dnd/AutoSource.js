/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/dnd/AutoSource",["../_base/declare","./Source"],function(_1,_2){
return _1("dojo.dnd.AutoSource",_2,{constructor:function(){
this.autoSync=true;
}});
});
