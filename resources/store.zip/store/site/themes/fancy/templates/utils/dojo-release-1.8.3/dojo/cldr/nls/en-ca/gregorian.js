/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-ca/gregorian",{"dateFormatItem-MMMMEd":"E, MMMM d","dateFormatItem-MMdd":"MM/dd","dateFormatItem-yyMMM":"MMM yy","dateFormatItem-MMMMd":"MMMM d"});
