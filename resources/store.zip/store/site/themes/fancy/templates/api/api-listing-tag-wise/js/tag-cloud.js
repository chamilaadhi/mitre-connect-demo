$(document).ready(function() {
    alert("ssfsfs");
    $("#tag-cloud .cloud-link").click(function() {
        alert("ha! you thought it works :)");
    });
});